#pragma warning(disable:4786)
#pragma warning(disable:4503)

#include <iostream>
#include <list>
#include <string>
#include <assert.h>
#include<unistd.h>
#include<fcntl.h>

#ifdef _ASSERTE
#  undef _ASSERTE
#endif
#define _ASSERTE	assert

#include "Logger/LoggerNotifyEvent.h"
#include "Config/ConfigDatabase.h"
#include "Config/StagingConfigDatabase.h"
#include "Common/Context.h"
#include "SessionLayer/Session.h"
#include "SessionLayer/MarketDataSubscriber.h"
#include "SessionLayer/MarketDataItemSub.h"
#include "Logger/AppLoggerMonitor.h"
#include "Logger/AppLogger.h"

#include "ssledclient.h"
#include "kdbrfassl.h"

#include "dbg.h"


using namespace rfa::sessionLayer;
using namespace rfa::logger;
using namespace rfa::common;

extern "C" void gather(char*, long, const char *);
extern "C" void publish(void);
extern "C" void rec(void);
extern "C" void dis(void);
extern "C" void stt(const char *, const char *, int );
extern "C" void set_rfa_init_done(int);
extern "C" void set_error_str(const char*);


extern int p[2]; // the pipe used to notify

static char RFA_CONFIG_FILE[] = "./etc/ssled.cfg";


//////////////////////////////////////////////////////////////////////
// Exception handler
//////////////////////////////////////////////////////////////////////

void printRfaException(Exception& e)
{
    DBG("enter");
    // Determine exception Severity
    RFA_String excpSeverityStr;
    switch ( e.getServerity() )
    {
    case Exception::Error:
        excpSeverityStr = RFA_String( "Error", 0, false );
        break;
    case Exception::Warning:
        excpSeverityStr = RFA_String( "Warning", 0, false );
        break;
    case Exception::Information:
        excpSeverityStr = RFA_String( "Information", 0, false );
        break;
    default:
        excpSeverityStr = RFA_String( "UNKNOWN Severity", 0, false );
        break;
    }

    // Determine exception Classification
    RFA_String excpClassificationStr;
    switch (e.getClassification())
    {
    case Exception::Anticipated:
        excpClassificationStr = RFA_String( "Anticipated", 0, false );
        break;
    case Exception::Internal:
        excpClassificationStr = RFA_String( "Internal", 0, false );
        break;
    case Exception::External:
        excpClassificationStr = RFA_String( "External", 0, false );
        break;
    case Exception::IncorrectAPIUsage:
        excpClassificationStr = RFA_String( "IncorrectAPIUsage", 0, false );
        break;
    case Exception::ConfigurationError:
        excpClassificationStr = RFA_String( "ConfigurationError", 0, false );
        break;
    default:
        excpClassificationStr = RFA_String( "UNKNOWN Classification", 0, false );
        break;
    }

    // Determine exception Type
    RFA_String excpTypeStr;
    RFA_String excpStatusText;
    RFA_String excpDetails;

    switch (e.getErrorType())
    {
    case Exception::InvalidUsageException:
    {
        excpTypeStr = RFA_String( "InvalidUsageException", 0, false );
        InvalidUsageException& actualException = static_cast<InvalidUsageException&>(e);
        excpStatusText = actualException.getStatus().getStatusText();
        break;
    }
    case Exception::InvalidConfigurationException:
    {
        excpTypeStr = RFA_String( "InvalidConfigurationException", 0, false );
        InvalidConfigurationException& actualException = static_cast<InvalidConfigurationException&>(e);
        excpStatusText = actualException.getStatus().getStatusText();
        excpDetails = actualException.getParameterName() + RFA_String( " ", 0, false );
        excpDetails += actualException.getParameterValue();
        break;
    }
    default:
    {
        excpStatusText = RFA_String( "Unknown Exception Type!", 0, false );
        break;
    }
    }

    // output exception information
    RFA_String tmpstr;
    tmpstr = RFA_String( "RFA EXCEPTION:", 0, false );
    tmpstr.append("\n");
    tmpstr.append("Exception Type: ");
    tmpstr.append(excpTypeStr);
    tmpstr.append("\n");
    tmpstr.append("Exception Severity: ");
    tmpstr.append(excpSeverityStr);
    tmpstr.append("\n");
    tmpstr.append("Exception Classification: ");
    tmpstr.append(excpClassificationStr);
    tmpstr.append("\n");
    tmpstr.append("Exception Status Text: ");
    tmpstr.append(excpStatusText);
    tmpstr.append("\n");
    if (!excpDetails.empty())
    {
        tmpstr.append(excpDetails);
        tmpstr.append("\n");
    }

    //  std::cerr << std::endl << std::endl;
    //  std::cerr << tmpstr.c_str();
    set_error_str(tmpstr.c_str());
    DBG("exit");
}

//////////////////////////////////////////////////////////////////////
// SsledClient Implementation
//////////////////////////////////////////////////////////////////////

SsledClient::SsledClient(rfa::common::EventQueue &eventQueue, rfa::sessionLayer::MarketDataSubscriber *subscriber):
        _eventQueue(eventQueue),
        _subscriber(subscriber)
{
    DBG("enter constructor");
    _pMarketDataItemSub = new MarketDataItemSub();
    if (!_pMarketDataItemSub)  std::cerr << "Fatal Error: unable to create MarketDataItemSub"  << std::endl;
    _ASSERTE (_pMarketDataItemSub);
    _pQoS = new QualityOfServiceRequest();
    if (!_pQoS)  std::cerr << "Fatal Error: unable to create MarketDataItemSub"  << std::endl;
    _ASSERTE (_pQoS);
    DBG("exit constructor");
}

SsledClient::~SsledClient()
{
    DBG("enter destructor");
    if (_pMarketDataItemSub) delete _pMarketDataItemSub;
    if (_pQoS) delete _pQoS;
    DBG("exit destructor");
}

void SsledClient::init(void)
{
    DBG("enter init");
    _pHandle = _subscriber->registerClient( _eventQueue, MarketDataSubscriberInterestSpec(true), *this, 0  );
    DBG("exit init");
}

void SsledClient::cleanup(void)
{
    _subscriber->unsubscribeAll();
}

int SsledClient::ssub(const std::string serviceName, const std::string subject)
{
    rfa::common::Handle* pHandle = 0;
    SUBMAP::const_iterator it;
    DBGX("ssub %s", subject.c_str());

    try
    {
        it = _subscribed.find(SUBPAIR(serviceName, subject));
        if (it != _subscribed.end())
        {
            DBGX("ssub: already subscribed %s", subject.c_str());
            //std::cerr << "INFO: pair ("<< serviceName << "," << subject<< ") is already subscribed."<< std::endl;
            pHandle = (*it).second;
        }
        else
        {
            _pMarketDataItemSub->setServiceName(RFA_String(serviceName.c_str(), 0, false));
            _pMarketDataItemSub->setItemName(RFA_String(subject.c_str(), 0, false));
            _pMarketDataItemSub->setSubject(RFA_String("", 0, false));
            _pMarketDataItemSub->setRequestedQualityOfService(*_pQoS);
            pHandle = _subscriber->subscribe(_eventQueue, *_pMarketDataItemSub, *this, NULL);
            _subscribed.insert(SUBMAP::value_type(SUBPAIR(serviceName, subject),pHandle));
        }
    }
    catch (rfa::common::Exception& e)
    {
        DBGX("ssub %s failed", subject.c_str());
        printRfaException(e);
        return -1;
    }
    DBGX("ssub %s completed", subject.c_str());
    return 0;
}

int SsledClient::ussub(const std::string serviceName, const std::string subject)
{
    rfa::common::Handle* pHandle = 0;
    SUBMAP::iterator it;
    DBGX("ussub %s", subject.c_str());

    try
    {
        it = _subscribed.find(SUBPAIR(serviceName, subject));
        if (it != _subscribed.end())
        {
            pHandle = (rfa::common::Handle*)(*it).second;
            if (!pHandle) {
                set_error_str("ussub: invalid handle");
                DBGX("ussub %s completed, invalid handle",subject.c_str());
                return -1;
            }
            _subscriber->unsubscribe(*pHandle);
            _subscribed.erase(it);
        }
        else
        {
            //std::cerr << "WARN: pair ("<< serviceName << "," << subject<< ") was not subscribed."<< std::endl;
            set_error_str(subject.c_str());
            DBGX("ussub completed with error for %s",subject.c_str());
            return -1;
        }
    }
    catch (rfa::common::Exception& e)
    {
        printRfaException(e);
        DBG("ussub completed with exception");
        return -1;
    }
    return 0;
}

// called when we get notification that there are messages in the event queue, reads exactly n events
void SsledClient::getEvents(int n)
{
    DBGX("getEvents n:%d",n);
    for (int i=0; i<n; i++) {
        if (_eventQueue.dispatch(0)==Dispatchable::NothingDispatched)
            ;//std::cerr << "Error: missing events"  << std::endl;
        DBGX("getEvents i:%d",i);
    }
    while (_eventQueue.dispatch(0)>0) {}
    DBG("getEvents loop completed");
    publish(); // publish gathered messages to Q
    DBG("exit");
}


void SsledClient::processEvent(const rfa::common::Event & event )
{
    DBGX("processEvent type:%d", event.getType());

    switch (event.getType())
    {
    case rfa::sessionLayer::MarketDataItemEventEnum:
    {
        const rfa::sessionLayer::MarketDataItemEvent & MDEvent = static_cast<const rfa::sessionLayer::MarketDataItemEvent&>(event);
        DBGX("MDEvent.getMarketDataMsgType(): %d",MDEvent.getMarketDataMsgType());
        switch (MDEvent.getMarketDataMsgType())
        {
        case rfa::sessionLayer::MarketDataItemEvent::Update:
        case rfa::sessionLayer::MarketDataItemEvent::Image:
        case rfa::sessionLayer::MarketDataItemEvent::UnsolicitedImage:
        case rfa::sessionLayer::MarketDataItemEvent::Correction:
        case rfa::sessionLayer::MarketDataItemEvent::ClosingRun:
        case rfa::sessionLayer::MarketDataItemEvent::Rename:
            DBG("Update, Image, UnsolicitedImage, Correction, ClosingRun or Rename\n");
            gather((char *) MDEvent.getBuffer().c_buf(),MDEvent.getBuffer().size(),MDEvent.getItemName().c_str());
            break;
        case rfa::sessionLayer::MarketDataItemEvent::Status:
            DBG("Status");
            stt(MDEvent.getItemName().c_str(), MDEvent.getStatus().getStatusText().c_str(), MDEvent.getStatus().getState());
            break;
        case rfa::sessionLayer::MarketDataItemEvent::PermissionData:
            DBG("PermissionData");
            break;
        default:
            DBG("Unknown MarketDataMsgType");
            break;
        }
        break;
    }
    case rfa::sessionLayer::ConnectionEventEnum:
    {
        const rfa::sessionLayer::ConnectionEvent& CEvent = static_cast<const rfa::sessionLayer::ConnectionEvent&>(event);
        DBGX("CEvent.getStatus().getState(): %d", CEvent.getStatus().getState());
        switch (CEvent.getStatus().getState())
        {
        case rfa::sessionLayer::ConnectionStatus::Up:
            rec();
            break;
        case rfa::sessionLayer::ConnectionStatus::Down:
            dis();
            break;
        default:
            DBG("Unknown state");
            break;
        };
        break;
    }
    case rfa::sessionLayer::MarketDataDictEventEnum:
    case rfa::sessionLayer::EntitlementsAuthenticationEventEnum:
    case rfa::sessionLayer::MarketDataSvcEventEnum:
        DBG("MarketDataDictEvent, EntitlementsAuthenticationEvent or MarketDataSvcEvent");
        break;
    default:
        break;
    }
    DBGX("processEvent type:%d completed", event.getType());
}

//////////////////////////////////////////////////////////////////////
// AppLoggerClient Implementation
//////////////////////////////////////////////////////////////////////

AppLoggerClient::AppLoggerClient()
{
}

AppLoggerClient::~AppLoggerClient()
{
}

void AppLoggerClient::processEvent(const rfa::common::Event& event)
{
    DBG("AppLoggerClient::processEvent enter");
    if (event.getType() == rfa::logger::LoggerNotifyEventEnum)
    {
        const rfa::logger::LoggerNotifyEvent* pCLogEvent = static_cast<const rfa::logger::LoggerNotifyEvent *>(&event);
        rfa::logger::LoggerNotifyEvent* pLogEvent = const_cast<rfa::logger::LoggerNotifyEvent *>(pCLogEvent);
        std::string  componentname = pLogEvent->getComponentName().c_str();
        long logid = pLogEvent->getLogID();
        long eventtype = pLogEvent->getSeverity();
        std::string msgtext = pLogEvent->getMessageText().c_str();
    }
    DBG("AppLoggerClient::processEvent exit");
}

//////////////////////////////////////////////////////////////////////
// Interface
//////////////////////////////////////////////////////////////////////

SsledClient *pSsledClient = 0;

extern "C" int ssub_c(const char* serv, const char* instr)
{
    DBG("enter");
    return pSsledClient->ssub(std::string(serv), std::string(instr));
    DBG("exit");
}

extern "C" int ussub_c(const char* serv, const char* instr)
{
    DBG("enter");
    return pSsledClient->ussub(std::string(serv), std::string(instr));
    DBG("exit");
}

// called from Q thread to collect messages
extern "C" void getEvents(int n)
{
    DBG("enter");
    pSsledClient->getEvents(n);
    DBG("exit");
}

extern "C" int tkmain(void)
{
    static rfa::config::ConfigDatabase *pDB = 0;
    static rfa::config::StagingConfigDatabase *pSDB = 0;
    static rfa::common::EventQueue *pEQueue = 0;
    static Session *pSession = 0;
    static MarketDataSubscriber *pMDSubscriber = 0;
    static ApplicationLogger *pLogger = 0;
    static AppLoggerMonitor *pLoggerMonitor = 0;
    static rfa::common::Handle* pLoggerHandle = 0;
    static AppLoggerClient *pLoggerClient = 0;
    static KdbNotificationClient notClient;
    DBG("enter");
    try
    {
        DBG("start");

        DBG("Initialize the context");
        if (!rfa::common::Context::initialize())
        {
            set_error_str("Can not initialize RFA Context");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }

        DBG("Populate the ConfigDatabase");
        pDB = rfa::config::ConfigDatabase::acquire(RFA_String("RFA", 0, false));
        if (!pDB) {
            set_error_str("Unable to create ConfigDatabase");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }
        DBG("create StagingConfigDatabase");
        pSDB = rfa::config::StagingConfigDatabase::create();
        if (!pSDB) {
            set_error_str("StagingConfigDatabase");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }
        DBG("merge config databases");
        if (!pSDB->load(rfa::config::flatFile, RFA_String(RFA_CONFIG_FILE, 0, false)) || !pDB->merge(*pSDB))
        {
            pSDB->destroy();
            pDB->release();
            rfa::common::Context::uninitialize();
            set_error_str("Unable to load RFA configuration");
            return(RFA_INIT_FAILURE); // signal falure in the rfa init
        }

        DBG("create event queue which will be shared to receive all events across this application");
        pEQueue = rfa::common::EventQueue::create(RFA_String("Queue1", 0, false));
        if (!pEQueue) {
            set_error_str("Unable to create EventQueue");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }

        DBG("Acquire application logger");
        pLogger = ApplicationLogger::acquire(RFA_String("RFA", 0, false));
        if (!pLogger)
        {
            //std::cerr << "Unable to acquire application logger. Terminating ... " << std::endl;
            pEQueue->destroy();
            pSDB->destroy();
            pDB->release();
            rfa::common::Context::uninitialize();
            set_error_str("Unable to acquire application logger.");
            return(RFA_INIT_FAILURE); // signal falure in the rfa init
        }
        DBG("create log monitor");
        pLoggerMonitor = pLogger->createApplicationLoggerMonitor(RFA_String("LoggerMonitor", 0, false), false);
        if (!pLoggerMonitor) {
            set_error_str("Unable to create ApplicationLoggerMonitor");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }
        rfa::logger::AppLoggerInterestSpec appLoggerInterestSpec;
        DBG("set logger to min severity");
        appLoggerInterestSpec.setMinSeverity(rfa::common::Success);
        pLoggerClient = new AppLoggerClient; // Create and register a logger client
        DBG("register logger client");
        pLoggerHandle = pLoggerMonitor->registerLoggerClient(*pEQueue,appLoggerInterestSpec,*pLoggerClient,NULL);

        DBG("Acquire a session");
        pSession = Session::acquire(RFA_String("SessionSSLED", 0, false));
        if (!pSession) {
            set_error_str("Unable to create Session");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }

        DBG("create market data subscriber and market data client");
        pMDSubscriber = pSession->createMarketDataSubscriber(RFA_String("MDSubscriber1", 0, false));
        if (!pMDSubscriber) {
            set_error_str("Unable to create MarketDataSubscriber");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }

        DBG("create SsledClient object");
        pSsledClient =  new SsledClient(*pEQueue, pMDSubscriber);
        if (!pSsledClient) {
            set_error_str("Unable to create SsledClient");
            return(RFA_INIT_FAILURE); // signal failure in the rfa init
        }

        DBG("initialize SsledClient object");
        pSsledClient->init();

        DBG("register notification client");
        pEQueue->registerNotificationClient( notClient, 0 );

        DBG("RFA_INIT_SUCCESS");
        return(RFA_INIT_SUCCESS); // signal end of initialization
    }
    catch (rfa::common::Exception& e)
    {
        DBG("RFA_INIT_FAILURE: exception");
        printRfaException(e);
        return(RFA_INIT_FAILURE); // signal falure in the rfa init
    }
    return NULL;
}

/////////////////////////////////////////////////////////////////////
// Notification client implementation
/////////////////////////////////////////////////////////////////////
static char b='\0';
KdbNotificationClient::KdbNotificationClient()
{
}
KdbNotificationClient::~KdbNotificationClient()
{
}

void KdbNotificationClient::notify(rfa::common::Dispatchable& eventSource, void* closure)
{
    DBG("enter");
    write(p[1], &b, 1);
    DBG("exit");
}
