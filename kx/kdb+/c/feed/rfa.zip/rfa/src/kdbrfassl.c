#include<pthread.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#include "kx/k.h"
#include"kdbrfassl.h"

#include "dbg.h"

//This is required by the Solaris compiler, it does not allow anonymous structures within anonymous unions.
typedef struct {
    I r;
    H t,u;
    union {
        G g;
        H h;
        I i;
        J j;
        E e;
        F f;
        S s;
        struct k0*k;
        struct {
            I n;
            G G0[1];
        } v;
    } Kvu;
}*Kv;
#define kvS(x) ((S*)((Kv)(x))->Kvu.v.G0) // kS replacement
#define kvJ(x) ((J*)((Kv)(x))->Kvu.v.G0) // kJ
#define kvK(x) ((K*)((Kv)(x))->Kvu.v.G0) // kK

//------------- interface to C++ part with RFA ---------------------------
extern int ssub_c(const char* serv, const char* instr);
extern int ussub_c(const char* serv, const char* instr);
extern int tkmain(void);
extern void getEvents(int n);

I p[2]; // the RFA notification pipe

ZC b[MAX_NO_MSGS];    // buffer for reading from pipe
ZK consume(I fd);     // reads from pipe and calls Q
ZK kbuf=NULL;         // for collecting messages read from RFA
ZK kitem=NULL;        // for collecting items read from RFA


char err_str[MAX_ERR_SIZE]; // for passing error string
static int rfa_init_done = RFA_INIT_NOT_DONE;

static I fmode;


//------------------------ interface:thread ---------------------------------//


char *ini(void)
{
    I i;
    DBG("start");
    if (pipe(p)) return ((char *) "pipe initialization failure");
    int f = fcntl(p[0],F_GETFL,0); // set pipe reader to nonblocking
    if (f==-1) return ((char *) "fcntl failed");
    f |= O_NONBLOCK;
    if (fcntl(p[0],F_SETFL,f)==-1) return ((char *) "fcntl failed");

    f = fcntl(p[1],F_GETFL,0); // set pipe reader to nonblocking
    if (f==-1) return ((char *) "fcntl failed");
    f |= O_NONBLOCK;
    if (fcntl(p[1],F_SETFL,f)==-1) return ((char *) "fcntl failed");

    sd1(p[0],consume);
    rfa_init_done=tkmain();
    if (RFA_INIT_FAILURE==rfa_init_done) return err_str; // returns NULL or error string
    DBG("completed");
    return NULL;
}

K init(K x)
{
    S s;
    fmode=x->t==10;
    DBGX("fmode=%d", fmode);

    if (s=(fmode||x->t==-11?NULL:"type"))return krr(s); // only for backward compatibility
    if (s=ini())return krr(s);
    DBG("completed");

    return NULL;
}


//------------------------ interface:sub ------------------------------------//
K ssub(K x, K y)
{
    if (x->t!=-11 || y->t!=11 && y->t!=-11) return(krr("type"));
    I v=y->t>0;
    S s;

    DBGX("ssub, rfa_init_done: %d", rfa_init_done);
    switch (rfa_init_done) {
    case RFA_INIT_FAILURE:
        return krr("ssub: initialization failed on previous attempt");
    case RFA_INIT_NOT_DONE:
        // first run of sub, create threads etc.
        s = ini();
        if (s) return krr(s);
        //if ini() successful, continue next case -> with subscription
    case RFA_INIT_SUCCESS:
        for (I i=0,_i=(v?((Kv)y)->Kvu.v.n:1); i<_i; ++i)
            if (ssub_c((const char *)xs, (const char *)v?kvS(y)[i]:((Kv)y)->Kvu.s))
                return krr(err_str);
        DBGX("ssub, rfa_init_done: %d completed", rfa_init_done);
        return r1(y);
    default:
        return krr("ssub: unexpected state of init");
    }
}

K ussub(K x, K y)
{
    if (x->t!=-11 || y->t!=11 && y->t!=-11) return(krr("type"));
    I v=y->t>0;
    S s;
    DBGX("ussub, rfa_init_done: %d", rfa_init_done);
    switch (rfa_init_done) {
    case RFA_INIT_FAILURE:
        return krr("ussub: initialization failed on previous attempt");
    case RFA_INIT_NOT_DONE:
        // first run of usub, create threads etc.
        if (s = ini()) return krr(s);
        //if ini() successful, continue next case -> with subscription
    case RFA_INIT_SUCCESS:
        for (I i=0,_i=(v?((Kv)y)->Kvu.v.n:1); i<_i; ++i)
            if (ussub_c((const char *)xs, (const char *)v?kvS(y)[i]:((Kv)y)->Kvu.s))
                return krr(err_str);
        return r1(y);
    default:
        return krr("ussub: unexpected state of init");
    }
}

K sub(K y)
{
    DBGX("sub, rfa_init_done: %d", rfa_init_done);
    K x=ks(ss((char *)"IDN_SELECTFEED"));
    return y= ssub(x,y),r0(x),y;
}

K usub(K y)
{
    DBGX("usub, rfa_init_done: %d", rfa_init_done);
    K x=ks(ss((char *)"IDN_SELECTFEED"));
    return y=ussub(x,y),r0(x),y;
}

//---------------------------- internal ------------------------------------//

K consume(I fd)
{
    I n;

    DBGX("consume fd:%d", fd);
    while (0<(n=read(fd,&b,PIPE_CAPACITY))) {
        getEvents(n);
    }
    DBG("exit");
    return NULL;
}

void gather(char* buff, long size, const char *item)
{
    K res;
    DBGX("enter, buff: 0x%x, size: %ld, item: 0x%x", (unsigned int) buff, size, (unsigned int)  item);
    if (!kbuf) {
        kbuf=knk(0); // first message in chunk, initialize buf
    }
    if (fmode && !kitem) {
        kitem=ktn(11,0); // first message in chunk, initialize buf
    }

    if (fmode) {
        res = js(&kitem,ss((char *)item));
        if (res->t == -128) fprintf(stderr,"produce: error when adding a symbol: %s\n", ((Kv)res)->Kvu.s);

        res=jk(&kbuf,kpn((char *)(1+(int)buff), size-2)); // add to the list of gathered strings
        if (res->t == -128) fprintf(stderr,"produce: error when adding a string: %s\n", ((Kv)res)->Kvu.s);
    }
    else {
        for (I i=0,_i=size; i<_i; ++i)
            if (buff[i]==30)buff[i]='\n'; //ATTENTION! changing rfa buffer memory!
        buff[size-1]='\n';              //ATTENTION! changing rfa buffer memory!

        res=jk(&kbuf,kpn((char *)buff, size)); // add to the list of gathered strings
        if (res->t == -128) fprintf(stderr,"produce: error when adding a string: %s\n", ((Kv)res)->Kvu.s);
    }
    DBG("exit");
}

void publish(void)
{
    DBG("enter");
    if (!kbuf) return;

    if (fmode) {
        DBG("publish f[s;x]");
        K res = k(0,(char *)"f",kitem,kbuf,(K)NULL);
        if (res->t == -128) fprintf(stderr,"signal from f[s;x]: '%s\n", ((Kv)res)->Kvu.s);
        r0(res);
        kbuf=NULL;
        kitem=NULL;
    }
    else {
        DBG("publish f[x]");
        K res = k(0,(char *)"f",kbuf,(K)NULL);
        if (res->t == -128) fprintf(stderr,"signal from f[x]: '%s\n", ((Kv)res)->Kvu.s);
        r0(res);
        kbuf=NULL;
    }
    DBG("exit");
}

void stt(const char * item, const char * status, int state)
{
    DBGX("stt item:%s status:%s state:%d",item, status, state);
    K res = k(0,"stt",ks((char *) item),ks((char*) status),ki(state),0);
    if (res->t == -128) fprintf(stderr,"signal from stt[x;y;z]: '%s\n", ((Kv)res)->Kvu.s);
    r0(res);
    DBG("exit");
}

void dis(void)
{
    DBG("enter");
    K res = k(0,"dis[]",(K)NULL);
    if (res->t == -128) fprintf(stderr,"signal from dis[]: '%s\n", ((Kv)res)->Kvu.s);
    r0(res);
    DBG("exit");
}

void rec(void)
{
    DBG("enter");
    K res = k(0,"rec[]",(K)NULL);
    if (res->t == -128) fprintf(stderr,"signal from rec[]: '%s\n", ((Kv)res)->Kvu.s);
    r0(res);
    DBG("exit");
}

void set_error_str(const char* str)
{
    DBG("enter");
    strncpy(err_str,str,MAX_ERR_SIZE);
    err_str[MAX_ERR_SIZE-1]='\0';
    DBG("exit");
}
