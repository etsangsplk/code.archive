#if !defined(DBG_H)
#define DBG_H

//#define DBGMSG
// note: these macros do not compile under Solaris
#ifdef DBGMSG
#  include <stdio.h>
#  define DBG(x) printf("%s:%d:%s(): "x"\n", __FILE__, __LINE__, __func__)
#  define DBGX(x,...) printf("%s:%d:%s(): "x"\n", __FILE__, __LINE__, __func__, __VA_ARGS__)
#else
#  define DBG(x)
#  define DBGX(x,...)
#endif

#endif



