#if !defined(SSLEDCLIENT_H)
#define SSLEDCLIENT_H

#ifndef WIN32
#include <cassert>
#undef _ASSERTE
#define _ASSERTE assert
#endif

#include <map>
#include "SessionLayer/MarketDataItemEvent.h"
#include "SessionLayer/MarketDataSubscriberInterestSpec.h"
#include "SessionLayer/EntitlementsAuthenticationEvent.h"
#include "SessionLayer/ConnectionEvent.h"
#include "Common/DispatchableNotificationClient.h"


// **************** KdbClient ************************
class SsledClient:public rfa::common::Client
{
public:
    SsledClient(rfa::common::EventQueue &eventQueue, rfa::sessionLayer::MarketDataSubscriber *subscriber);
    virtual ~SsledClient();

    void init(void);
    void cleanup(void);
    int ssub(const std::string serviceName, const std::string subject);
    int ussub(const std::string serviceName, const std::string subject);
    void getEvents(int);

protected:
    void processEvent(const rfa::common::Event & event);

private:
    rfa::sessionLayer::MarketDataSubscriber* _subscriber;
    rfa::common::EventQueue& _eventQueue;
    bool _receivedConnectionUp;
    rfa::common::Handle* _pHandle;
    rfa::common::QualityOfServiceRequest* _pQoS;
    rfa::sessionLayer::MarketDataItemSub* _pMarketDataItemSub;

    typedef std::pair<std::string, std::string> SUBPAIR;
    typedef std::map<SUBPAIR,rfa::common::Handle*> SUBMAP;

    SUBMAP _subscribed;
    std::list<SUBPAIR> _requested;

    SsledClient(const SsledClient&);
    SsledClient& operator=(const SsledClient&);
};

// **************** AppLoggerClient ************************
/** Receive log notifications from RFA ApplicationLogger */
class AppLoggerClient: public rfa::common::Client
{
public:
    AppLoggerClient();
    virtual ~AppLoggerClient();
    virtual void processEvent(const rfa::common::Event & event );

private:
    AppLoggerClient(const AppLoggerClient&);
    AppLoggerClient& operator=(const AppLoggerClient&);
};

class KdbNotificationClient: public rfa::common::DispatchableNotificationClient
{
public:
    KdbNotificationClient();
    virtual ~KdbNotificationClient();
    void notify( rfa::common::Dispatchable& eventSource, void* closure );
    void init( rfa::common::Dispatchable& disp);
};

#endif // !defined(SSLEDCLIENT_H)
